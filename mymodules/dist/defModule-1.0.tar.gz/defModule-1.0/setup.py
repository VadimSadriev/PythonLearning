from setuptools import setup

setup(
    name='defModule',
    version= '1.0',
    description='First module',
    author='HF Python 2e',
    author_email='sadrievvadimtww@yandex.ru',
    url=';)',
    py_modules=['defModule']
)