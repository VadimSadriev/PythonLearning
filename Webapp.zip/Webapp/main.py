from flask import Flask, render_template,request, redirect
import defModule
app = Flask(__name__)


# @app.route('/')
# def hello() -> str:
#     return redirect('/entry')


@app.route('/search4', methods=['POST'])
def do_search():
    title = 'Here are ur results'
    phrase= request.form['phrase']
    letters= request.form['letters']
    return render_template('results.html', the_results=defModule.search4letter(phrase, letters).__str__(),
                           the_phrase=phrase,
                           the_letters= letters,
                           the_title=title)

@app.route('/')
@app.route('/entry')
def index() -> 'html':
    return render_template('entry.html',
                           the_title='Welcome to search4letters on the web!')


if __name__ == '__main__':
    app.run(debug=True)